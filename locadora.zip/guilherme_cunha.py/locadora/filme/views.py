from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Filmes
from .forms import FilmesForm

def base(request):
    filme = Filmes.objects.all()
    template_name = 'base.html'
    context = {
        'filmes': filme
    }
    return render(request, template_name, context)

def filme_list(request):
    filme = Filmes.objects.all()
    template_name = 'filme_list.html'
    context = {
        'filmes': filme
    }
    return render(request, template_name, context)

def filme_new(request):
    print('O método é: ', request.method)
    if request.method == 'POST':
        form = FilmesForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('filme_list')
    else:
        template_name = 'filme_new.html'
        context = {'form': FilmesForm()}
        return render(request, template_name, context)

def filme_edit(request, pk):
    filme = Filmes.objects.get(id=pk)
    if request.method == 'POST':
        form = FilmesForm(request.POST, instance=filme)
        if form.is_valid():
            form.save()
            return redirect('filme_list')
    else:
        template_name = 'filme_edit.html'
        context = {'form': FilmesForm(instance=filme), 'pk': pk}
        return render(request, template_name, context)

def filme_delete(request, pk):
    filme = Filmes.objects.get(id=pk)
    filme.delete()
    return redirect('filme_list')

    
# Create your views here.
