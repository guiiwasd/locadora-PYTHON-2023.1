from django.contrib import admin
from .models import Filmes, Generos
    
class FilmesAdmin(admin.ModelAdmin):
    list_display = ['filme', 'genero', 'quantidade', 'preco']
    search_fields = ['filme']
    list_filter = ['genero']
admin.site.register(Filmes, FilmesAdmin)

class GenerosAdmin(admin.ModelAdmin):
    list_display = ['genero']
admin.site.register(Generos, GenerosAdmin)


# Register your models here.
