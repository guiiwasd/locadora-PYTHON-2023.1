from django.db import models

class Generos(models.Model):
    genero = models.CharField('Nome', max_length=100)

    class Meta:
        verbose_name = 'Genero'
        verbose_name_plural = 'Generos'
        ordering = ['genero']

    def __str__(self):
        return self.genero

class Filmes(models.Model):
    filme = models.CharField('Nome', max_length=100)
    genero = models.ForeignKey(Generos, on_delete=models.PROTECT)
    quantidade = models.IntegerField('Quantidade', default=0)
    preco = models.DecimalField('Preço', decimal_places=2, max_digits=8)

    class Meta: 
        verbose_name = 'Filme'
        verbose_name_plural = 'Filmes'
        ordering = ['filme', 'genero', 'quantidade', 'preco']

    def __str__(self):
        return self.filme




# Create your models here.
